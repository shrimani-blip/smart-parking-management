# Smart Parking Management System (Java)

## Features
- Java Swing desktop interface
- SQLite database persistence
- 10 sample parking slots across two zones
- Book an available slot using a vehicle registration number
- Release an occupied slot
- Live availability summary and activity log
- Parameterised SQL and transactions for booking/release operations

## Requirements
- JDK 17 or later
- Apache Maven 3.8+ (internet access for the first dependency download)

## Run
From this folder:
```bash
mvn clean compile exec:java
```
A local `smartparking.db` file is created automatically on first launch.

## Notes
This is a college demonstration prototype. It does not connect to physical sensors, a real JioTag device, payment services, or a live cloud backend. The report includes an illustrative IoT extension concept. Do not represent the generated illustration as an authentic JioTag product photograph.
