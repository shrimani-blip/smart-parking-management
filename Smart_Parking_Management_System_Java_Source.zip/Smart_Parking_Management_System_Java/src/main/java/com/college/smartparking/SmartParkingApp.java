package com.college.smartparking;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Smart Parking Management System - Java Swing + SQLite.
 * Educational prototype. The application uses a local SQLite database.
 */
public class SmartParkingApp extends JFrame {
    private static final String DB_URL = "jdbc:sqlite:smartparking.db";
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Slot ID", "Location", "Type", "Status", "Vehicle No.", "Booked At"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel summary = new JLabel("Loading parking data...");
    private final JTextField vehicleField = new JTextField(12);
    private final JComboBox<String> slotBox = new JComboBox<>();

    public SmartParkingApp() {
        super("Smart Parking Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(920, 600);
        setLocationRelativeTo(null);
        initialiseDatabase();
        buildUi();
        refreshSlots();
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    private void initialiseDatabase() {
        try (Connection c = connect(); Statement st = c.createStatement()) {
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS parking_slots (
                    slot_id INTEGER PRIMARY KEY,
                    location TEXT NOT NULL,
                    slot_type TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'AVAILABLE'
                        CHECK(status IN ('AVAILABLE','OCCUPIED')),
                    vehicle_no TEXT,
                    booked_at TEXT
                )
            """);
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS parking_log (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    slot_id INTEGER NOT NULL,
                    vehicle_no TEXT NOT NULL,
                    action TEXT NOT NULL,
                    event_time TEXT NOT NULL,
                    FOREIGN KEY(slot_id) REFERENCES parking_slots(slot_id)
                )
            """);
            try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM parking_slots")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO parking_slots(slot_id,location,slot_type) VALUES(?,?,?)")) {
                        String[] types = {"CAR", "CAR", "CAR", "EV", "TWO-WHEELER", "TWO-WHEELER",
                                          "CAR", "EV", "CAR", "TWO-WHEELER"};
                        for (int i = 1; i <= types.length; i++) {
                            ps.setInt(1, i);
                            ps.setString(2, "Zone " + ((i - 1) / 5 + 1));
                            ps.setString(3, types[i - 1]);
                            ps.addBatch();
                        }
                        ps.executeBatch();
                    }
                }
            }
        } catch (SQLException ex) {
            showError("Could not initialise database: " + ex.getMessage());
        }
    }

    private void buildUi() {
        setLayout(new BorderLayout(12, 12));
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(23, 54, 93));
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel title = new JLabel("SMART PARKING MANAGEMENT");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        header.add(title, BorderLayout.NORTH);
        summary.setForeground(Color.WHITE);
        summary.setFont(new Font("SansSerif", Font.PLAIN, 14));
        header.add(summary, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        table.setRowHeight(26);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel controls = new JPanel(new GridBagLayout());
        controls.setBorder(BorderFactory.createTitledBorder("Parking Actions"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 6, 5, 6);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0; g.gridy = 0; controls.add(new JLabel("Vehicle number:"), g);
        g.gridx = 1; controls.add(vehicleField, g);
        g.gridx = 2; controls.add(new JLabel("Available slot:"), g);
        g.gridx = 3; controls.add(slotBox, g);
        JButton book = new JButton("Book Slot");
        JButton release = new JButton("Release Selected");
        JButton refresh = new JButton("Refresh");
        JButton log = new JButton("View Activity Log");
        g.gridx = 0; g.gridy = 1; controls.add(book, g);
        g.gridx = 1; controls.add(release, g);
        g.gridx = 2; controls.add(refresh, g);
        g.gridx = 3; controls.add(log, g);
        add(controls, BorderLayout.SOUTH);

        book.addActionListener(e -> bookSlot());
        release.addActionListener(e -> releaseSlot());
        refresh.addActionListener(e -> refreshSlots());
        log.addActionListener(e -> showLog());
    }

    private void refreshSlots() {
        model.setRowCount(0);
        slotBox.removeAllItems();
        int available = 0, occupied = 0;
        try (Connection c = connect();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM parking_slots ORDER BY slot_id")) {
            while (rs.next()) {
                String status = rs.getString("status");
                if ("AVAILABLE".equals(status)) {
                    available++;
                    slotBox.addItem(rs.getInt("slot_id") + " - " + rs.getString("slot_type")
                            + " (" + rs.getString("location") + ")");
                } else occupied++;
                model.addRow(new Object[]{rs.getInt("slot_id"), rs.getString("location"),
                        rs.getString("slot_type"), status, rs.getString("vehicle_no"),
                        rs.getString("booked_at")});
            }
            summary.setText("Total slots: " + (available + occupied) + "    Available: "
                    + available + "    Occupied: " + occupied);
        } catch (SQLException ex) {
            showError("Could not load slots: " + ex.getMessage());
        }
    }

    private void bookSlot() {
        String vehicle = vehicleField.getText().trim().toUpperCase();
        if (vehicle.isEmpty()) {
            showError("Enter a vehicle number first.");
            return;
        }
        Object selected = slotBox.getSelectedItem();
        if (selected == null) {
            showError("No available slot. Refresh or release a slot.");
            return;
        }
        int slotId = Integer.parseInt(selected.toString().split(" - ")[0]);
        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        try (Connection c = connect()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE parking_slots SET status='OCCUPIED', vehicle_no=?, booked_at=? " +
                    "WHERE slot_id=? AND status='AVAILABLE'")) {
                ps.setString(1, vehicle); ps.setString(2, now); ps.setInt(3, slotId);
                if (ps.executeUpdate() != 1) {
                    c.rollback();
                    showError("That slot is no longer available. Refresh and try again.");
                    return;
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO parking_log(slot_id,vehicle_no,action,event_time) VALUES(?,?,?,?)")) {
                ps.setInt(1, slotId); ps.setString(2, vehicle);
                ps.setString(3, "BOOKED"); ps.setString(4, now); ps.executeUpdate();
            }
            c.commit();
            vehicleField.setText("");
            refreshSlots();
            JOptionPane.showMessageDialog(this, "Slot " + slotId + " booked for " + vehicle + ".");
        } catch (SQLException ex) {
            showError("Booking failed: " + ex.getMessage());
        }
    }

    private void releaseSlot() {
        int row = table.getSelectedRow();
        if (row < 0) {
            showError("Select an occupied slot in the table.");
            return;
        }
        int slotId = (int) model.getValueAt(row, 0);
        String status = String.valueOf(model.getValueAt(row, 3));
        String vehicle = String.valueOf(model.getValueAt(row, 4));
        if (!"OCCUPIED".equals(status)) {
            showError("The selected slot is already available.");
            return;
        }
        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        try (Connection c = connect()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE parking_slots SET status='AVAILABLE', vehicle_no=NULL, booked_at=NULL " +
                    "WHERE slot_id=? AND status='OCCUPIED'")) {
                ps.setInt(1, slotId);
                if (ps.executeUpdate() != 1) {
                    c.rollback();
                    showError("Slot state changed. Refresh and retry.");
                    return;
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO parking_log(slot_id,vehicle_no,action,event_time) VALUES(?,?,?,?)")) {
                ps.setInt(1, slotId); ps.setString(2, vehicle);
                ps.setString(3, "RELEASED"); ps.setString(4, now); ps.executeUpdate();
            }
            c.commit();
            refreshSlots();
            JOptionPane.showMessageDialog(this, "Slot " + slotId + " released.");
        } catch (SQLException ex) {
            showError("Release failed: " + ex.getMessage());
        }
    }

    private void showLog() {
        StringBuilder text = new StringBuilder();
        try (Connection c = connect(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM parking_log ORDER BY log_id DESC LIMIT 100")) {
            while (rs.next()) {
                text.append("#").append(rs.getInt("log_id"))
                    .append(" | Slot ").append(rs.getInt("slot_id"))
                    .append(" | ").append(rs.getString("vehicle_no"))
                    .append(" | ").append(rs.getString("action"))
                    .append(" | ").append(rs.getString("event_time")).append("\n");
            }
        } catch (SQLException ex) {
            showError("Could not load activity log: " + ex.getMessage());
            return;
        }
        JTextArea area = new JTextArea(text.length() == 0 ? "No activity recorded yet." : text.toString(), 18, 60);
        area.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Recent Activity", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Smart Parking", JOptionPane.WARNING_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SmartParkingApp().setVisible(true));
    }
}
